#include<iostream>
using namespace std;
int main()
{
    int a,b,x;
    cin>>a>>b;
    x=a+b;
    cout<<"X "<<"= "<<x<<endl;
    return 0;
}
