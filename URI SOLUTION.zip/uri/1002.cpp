#include <iostream>
#include <iomanip>

using namespace std;
 
int main() {
 
     double R,pi=3.14159;
  cin>>R;
  cout<<"A="<<fixed<<setprecision(4)<<pi*(R*R)<<endl;
  
  return 0;
    
}
