#include <iostream>
 
using namespace std;
 
int main() {
 
   int A,B;
   cin>>A>>B;
   cout<<"SOMA "<<"= "<<A+B<<endl;
 
    return 0;
}
