#include <iostream>
 
using namespace std;
 
int main() {
 
     int A,B;
   cin>>A>>B;
   cout<<"PROD "<<"= "<<A*B<<endl;
 
    return 0;
}
