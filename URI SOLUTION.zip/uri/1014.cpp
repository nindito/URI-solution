#include<iostream>
using namespace std;

int main()

{

    int X;

    float Y;

    scanf("%d %f", &X, &Y);

    printf("%.3f km/l\n", X / Y);

    return 0;

}

