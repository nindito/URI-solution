#include<iostream>
using namespace std;

int main(){

    int distance;

    cin>>distance;

    cout<<2 * distance<<" minutos"<<endl;

    return 0;

}
