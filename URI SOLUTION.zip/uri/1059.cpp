#include<bits/stdc++.h>
using namespace std;

int main()
{
 int n = 100,i;
 for( i =2; i <= n; i=i+2)
 {
  printf("%d\n", i);
 }
 return 0;
}
