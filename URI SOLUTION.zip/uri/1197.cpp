#include <iostream>
#include <string>

using namespace std;

int main(){
    
    for(int v,t;scanf("%d%d",&v,&t) != EOF;printf("%d\n",v * (2*t))){} 
     
 return 0;   
}
