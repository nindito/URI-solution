#include <iostream>
#include<algorithm>

using namespace std;

int main() {
	long long  a, b,c;
	while (cin >> a >> b) {
	 c=max(a,b) - min(a,b);
        cout<<c<<endl;

	}
	return 0;
}
