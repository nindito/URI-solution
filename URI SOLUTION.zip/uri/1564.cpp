#include <iostream>
using namespace std;

int main()
{
	int n;
	while(cin >> n)
	{
		if(n > 0){
			printf("vai ter duas!\n");
		}else{
			printf("vai ter copa!\n");
		}
	}
	return 0;
}
