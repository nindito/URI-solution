#include <iostream>

using namespace std;

int main()
{
    int a,i;
    char ar[50]="LIFE IS NOT A PROBLEM TO BE SOLVED";
   cin>>a;
    for(i=0; i<a; i++)
       cout<<ar[i];
   cout<<endl;
    return 0;
}
