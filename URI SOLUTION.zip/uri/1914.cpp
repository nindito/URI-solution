#include<iostream>
#include<cstring>
using namespace std;

int main()
{
    
    long long int x,y,T ;
    char a[201], b[10], c[201], d[10];
    cin>>T;
    for(int i=0; i<T; i++)
    {
        cin>>a>>b>>c>>d;
        cin>>x>>y;
        
        if( b[0]=='P' )
        {
            if((x+y)%2==0) cout<<a<<endl;
            else  cout<<c<<endl;
        }
        else
        {
            if((x+y)%2==0) cout<<c<<endl;
            else cout<<a<<endl;
        }
    }
    return 0;
}
