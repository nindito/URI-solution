#include<iostream>
using namespace std;

int main() {
 long long int n;
    cin>>n;
    cout<<n*(n-3)/2<<endl;
}
