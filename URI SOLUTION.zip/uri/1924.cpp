#include <iostream>

int main() {
    std::cout << "Ciencia da Computacao" << std::endl;

    return 0;
}
