#include <iostream>

int main() {
    int t1, t2, t3, t4;

    std::cin >> t1 >> t2 >> t3 >> t4;
    std::cout << t1 + t2 + t3 + t4 - 3 << std::endl;

    return 0;
}
