#include <iostream>
 using namespace std;

int main()
{
    int p, q, c=0, i, dif;
    cin>>p>>q;
    int jump[q];
    for(i=0; i<q; i++)
        cin>>jump[i];
    for(i=1; i<q; i++)
    {
        if(jump[i]>jump[i-1])
         dif = (jump[i] - jump[i-1]);
        else
         dif = (jump[i-1] - jump[i]);
        if(dif<=p)
            c++;
    }
    if(c== q-1)
        printf("YOU WIN\n");
    else
        printf("GAME OVER\n");
    return 0;
}
