#include<iostream>
#include<algorithm>
#include<vector>
#include<cstring>
using namespace std;
 
 
int main (){
	string line;
	  while (cin >> line) {
    reverse(line.begin(), line.end());
    cout << line << endl;
  }
  return 0;
}
