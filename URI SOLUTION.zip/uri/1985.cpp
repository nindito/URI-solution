#include <iostream>
#include<cstdlib>
#include <map>
#include <iomanip>

using namespace std;

int main() {
    map<int, float> menu;
    menu[1001] = 1.5;
    menu[1002] = 2.5;
    menu[1003] = 3.5;
    menu[1004] = 4.5;
    menu[1005] = 5.5;

    int p, q, id = 0;
    float sum = 0.0;

    cin >> p;

    while (p--) {
      cin >> id >> q;
        sum += menu[id] * q;
    }

    cout <<setprecision(2) <<fixed <<sum <<endl;

    return 0;
}
