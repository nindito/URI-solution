#include <iostream>
 
using namespace std;

int main()
{
    int s, t, f, ans;
   cin>>s>>t>>f;
    ans = s+t+f;
    if(ans < 0) ans = 24 + ans;
   cout<<ans%24<<endl;
    return 0;
}
